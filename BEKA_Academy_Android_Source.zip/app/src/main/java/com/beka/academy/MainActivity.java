package com.beka.academy;
import android.app.*;import android.os.*;import android.webkit.*;import android.view.*;import android.graphics.Color;
public class MainActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b); WebView w=new WebView(this); w.setBackgroundColor(Color.rgb(11,13,12)); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true); w.loadUrl("file:///android_asset/index.html"); setContentView(w);}
}